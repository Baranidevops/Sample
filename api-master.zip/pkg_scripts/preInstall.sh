#!/bin/sh
mkdir -p /usr/tmp-cpl/share/tomcat/conf
mkdir -p /usr/share/script
mkdir -p /etc/tmp-cpl/httpd
mkdir -p /opt/tmp
mkdir -p /etc/tmp-cpl/systemd/system
export JAVA_HOME=/usr/java/default
export PATH=$PATH:$JAVA_HOME/bin
